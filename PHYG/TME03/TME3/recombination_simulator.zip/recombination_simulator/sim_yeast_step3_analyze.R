# Author: Raphael Champeimont
# UMR 7238 Biologie Computationnelle et Quantitative

setwd("~/Documents/PhyChro/sim")

params <- list(
  outDirectory = "results_yeast1")

source("scripts/sim_analyze_phychro.R")
